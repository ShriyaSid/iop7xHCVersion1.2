package testBase;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import com.mailosaur.MailosaurException;




/**
 * @author Shriya Siddarth
   @version 1.2
 */

public class TestRunner {

	
	
	public static void main(String[] args) throws IOException, MailosaurException, InterruptedException {
		// TODO Auto-generated method stub
		TestBase t=new TestBase();
		t.setup("Chrome");
		//t.tearDown();
		
		
		//CreateCitizenAccount c=new CreateCitizenAccount();
		//c.create7XAccount();
		ForgotUsernameOHID obj=new ForgotUsernameOHID();
		obj.checkForgotUsernameOHID();
		
		t.tearDown();
	}

}
